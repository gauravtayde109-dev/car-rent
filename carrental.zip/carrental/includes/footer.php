<footer>
  <div class="footer-top">
    <div class="container">
      <div class="row">
      
        <div class="col-md-6">
          <h6>About</h6>
          <ul>
            <li><a href="page.php?type=aboutus">About Me</a></li>
            <li><a href="page.php?type=privacy">Privacy Policy</a></li>
            <li><a href="contact-us.php">Contact Me</a></li>
            <li><a href="admin/">Admin Login</a></li>
          </ul>
        </div>
  
        <div class="col-md-3 col-sm-6">
          <h6>Subscribe News letter</h6>
          <div class="newsletter-form">
            <form method="post">
              <div class="form-group">
                <input type="email" name="subscriberemail" class="form-control newsletter-input" required placeholder="Enter Email Address" />
              </div>
              <button type="submit" name="emailsubscibe" class="btn btn-block">Subscribe 
                <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
              </button>
            </form>
            <p class="subscribed-text">*We send great deals and latest auto news to our subscribed users every week.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-md-push-6 text-right">
          <div class="footer_widget">
            <p>Connect with Me:</p>
            <ul>
              <li><a href="https://www.facebook.com/gauravtayde109" target="_blank"><i class="fa fa-facebook-square"></i></a></li>
              <li><a href="https://www.instagram.com/gauravtayde109" target="_blank"><i class="fa fa-instagram"></i></a></li>
              <li><a href="https://www.linkedin.com/in/gauravtayde109" target="_blank"><i class="fa fa-linkedin-square"></i></a></li>
              <li><a href="mailto:gauravtayde109@gmail.com" target="_blank"><i class="fa fa-envelope"></i></a></li>
            </ul>
          </div>
        </div>

        <div class="col-md-6 col-md-pull-6">
          <p class="copy-right">© 2025  Car Rental Portal</p>
        </div>
      </div>
    </div>
  </div>
</footer>
